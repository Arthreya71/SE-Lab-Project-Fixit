'use strict';
// Progressive enhancements only. All core workflows use normal HTML forms.
(() => {
  const root = document.documentElement;
  let savedTheme = null;
  try { savedTheme = localStorage.getItem('fixit-theme'); } catch (_) { /* Storage is optional. */ }
  root.dataset.theme = savedTheme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  document.querySelectorAll('.theme-toggle').forEach(button => {
    button.addEventListener('click', () => {
      root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem('fixit-theme', root.dataset.theme); } catch (_) { /* Optional. */ }
    });
  });
  const menu = document.querySelector('.mobile-menu');
  const sidebar = document.querySelector('.sidebar');
  if (menu && sidebar) {
    menu.addEventListener('click', () => {
      const open = sidebar.classList.toggle('open');
      menu.setAttribute('aria-expanded', String(open));
      menu.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
    });
    const closeMenu = () => { sidebar.classList.remove('open'); menu.setAttribute('aria-expanded', 'false'); menu.setAttribute('aria-label', 'Open navigation'); };
    document.addEventListener('click', event => {
      if (!sidebar.contains(event.target) && !menu.contains(event.target)) closeMenu();
    });
    document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
  }
  document.querySelectorAll('.toast-close').forEach(button => button.addEventListener('click', () => button.closest('.toast').remove()));
  document.querySelectorAll('[data-demo]').forEach(button => {
    button.addEventListener('click', () => {
      const form = document.querySelector('.auth-form-wrap form');
      form.elements.username.value = button.dataset.demo;
      form.elements.password.value = button.dataset.password;
      form.querySelector('button[type="submit"]').focus();
    });
  });
  document.querySelectorAll('.password-toggle').forEach(button => {
    button.addEventListener('click', () => {
      const input = document.getElementById(button.dataset.target);
      const showing = input.type === 'password';
      input.type = showing ? 'text' : 'password';
      button.textContent = showing ? 'Hide' : 'Show';
      button.setAttribute('aria-label', showing ? 'Hide password' : 'Show password');
    });
  });
  document.querySelectorAll('[data-counter]').forEach(input => {
    const counter = document.getElementById(input.dataset.counter);
    const update = () => { counter.textContent = `${input.value.length.toLocaleString()} / 2,000`; };
    input.addEventListener('input', update); update();
  });
  const dialog = document.getElementById('confirm-dialog');
  let pendingForm = null;
  let confirmed = false;
  document.querySelectorAll('[data-confirm-delete]').forEach(form => {
    form.addEventListener('submit', event => {
      if (confirmed) return;
      if (dialog && typeof dialog.showModal === 'function') {
        event.preventDefault(); pendingForm = form; dialog.showModal();
      } else if (!confirm('Permanently delete this issue and its activity?')) {
        event.preventDefault();
      }
    });
  });
  if (dialog) {
    document.getElementById('cancel-delete').addEventListener('click', () => { dialog.close(); pendingForm = null; });
    document.getElementById('confirm-delete').addEventListener('click', () => {
      if (pendingForm) { confirmed = true; dialog.close(); pendingForm.requestSubmit(); }
    });
    dialog.addEventListener('cancel', () => { pendingForm = null; });
    dialog.addEventListener('click', event => {
      if (event.target === dialog) {
        const r = dialog.getBoundingClientRect();
        if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) { dialog.close(); pendingForm = null; }
      }
    });
  }
})();
