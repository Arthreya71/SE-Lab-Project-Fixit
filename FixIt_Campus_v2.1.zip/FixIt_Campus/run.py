"""Cross-platform local launcher. Run: python run.py"""
import os
from app import create_app

if __name__ == '__main__':
    app = create_app()
    host = os.environ.get('HOST', '127.0.0.1')
    port = int(os.environ.get('PORT', '5000'))
    try:
        from waitress import serve
    except ImportError:
        print('Waitress is not installed. Using the local Flask server (debug OFF).')
        print('Open http://127.0.0.1:' + str(port))
        app.run(host=host, port=port, debug=False)
    else:
        print('FixIt Campus is ready at http://127.0.0.1:' + str(port))
        print('Press Ctrl+C to stop.')
        serve(app, host=host, port=port, threads=4)
