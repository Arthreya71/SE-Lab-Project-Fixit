# FixIt Campus 2.1

## New features
- **Insights page (admin):** resolution rate, average time to fix, satisfaction score, overdue count, issues by category, priority mix, a 7-day reported-vs-resolved chart and location hotspots. Charts are plain SVG, so they work offline and under the strict CSP.
- **Ratings and feedback:** students rate a resolved issue from 1 to 5 stars with an optional note; admins see the feedback on the issue.
- **Campus notices:** admins publish short announcements that appear on every dashboard.
- Three new automated tests (53 in total). New tables are created automatically on an existing database.

# FixIt Campus 2.0

## A complete visual refresh
- Handcrafted welcome page and campus illustration.
- Emerald workspace with reusable icons, cards, progress ring and activity feed.
- Responsive mobile navigation, dark theme, feedback toasts and deletion dialog.
- Native forms, focus states, reduced-motion preferences and print styling.

## Useful new workflows
- Student registration and profile/password settings.
- Location-aware reporting and editable Submitted issues.
- Dedicated issue pages, persistent comments and event history.
- Reopening a resolved issue with a reason.
- Administrator assignment labels, planned due dates and overdue tracking.
- Search, combined filters, priority sorting, pagination and scoped CSV export.

## A stronger project foundation
- Application factory, conventional templates/static layout and declarative schema.
- Server validation, constrained database fields and foreign-key enforcement.
- CSRF-protected POSTs, POST-only logout, locally generated secret and security headers.
- Basic login throttling, safe CSV cells and explicit connection teardown.
- 50 automated integration tests and recorded representative Chromium browser checks.
- Windows/macOS/Linux launchers and two pinned direct runtime dependencies.
- Rewritten SRS, six UML diagrams, project report and user guide; editable versions included.

This release uses a new schema. It does not migrate the original application's database. Use a fresh extracted folder. Runtime databases, virtual environments, caches and signing secrets are deliberately excluded from the ZIP.
