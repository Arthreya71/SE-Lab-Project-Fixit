"""FixIt Campus — a small, self-contained Flask complaint-management project."""
import csv
import io
import os
import secrets
import sqlite3
from datetime import date, timedelta
from functools import wraps
from pathlib import Path
from flask import Flask, abort, flash, g, make_response, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

ROOT = Path(__file__).resolve().parent
CATEGORIES = ['Electrical', 'Plumbing', 'Internet / Wi-Fi', 'Cleanliness', 'Mess / Food', 'Other']
STATUSES = ['Submitted', 'In Progress', 'Resolved']
PRIORITIES = ['Low', 'Medium', 'High']


def create_app(config=None):
    app = Flask(__name__, instance_relative_config=True)
    Path(app.instance_path).mkdir(exist_ok=True)
    secret_path = Path(app.instance_path) / '.session-secret'
    secret = os.environ.get('SECRET_KEY')
    if not secret:
        if not secret_path.exists():
            secret_path.write_text(secrets.token_hex(32))
            try:
                secret_path.chmod(0o600)
            except OSError:
                pass
        secret = secret_path.read_text().strip()
    app.config.update(SECRET_KEY=secret, DATABASE=str(Path(app.instance_path) / 'fixit.db'),
                      SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                      SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE') == '1',
                      MAX_CONTENT_LENGTH=64 * 1024,
                      DEMO_MODE=os.environ.get('DEMO_MODE', '1') == '1')
    if config:
        app.config.update(config)

    def db():
        if 'db' not in g:
            g.db = sqlite3.connect(app.config['DATABASE'], timeout=10)
            g.db.row_factory = sqlite3.Row
            g.db.execute('PRAGMA foreign_keys = ON')
        return g.db

    @app.teardown_appcontext
    def close_db(error=None):
        connection = g.pop('db', None)
        if connection is not None:
            connection.close()

    def event(cid, kind, body):
        db().execute('INSERT INTO events(complaint_id,user_id,kind,body) VALUES(?,?,?,?)',
                     (cid, g.user['id'], kind, body))

    def allowed(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not g.user:
                flash('Please sign in to continue.', 'info')
                return redirect(url_for('login'))
            return view(*args, **kwargs)
        return wrapped

    def admin():
        if not g.user or g.user['role'] != 'admin':
            abort(403)

    def ticket(cid):
        row = db().execute('SELECT c.*, u.name AS owner_name, u.username AS owner_username FROM complaints c JOIN users u ON c.user_id=u.id WHERE c.id=?', (cid,)).fetchone()
        if row is None:
            abort(404)
        if g.user['role'] != 'admin' and row['user_id'] != g.user['id']:
            abort(403)
        return row

    @app.before_request
    def load_user_and_csrf():
        g.user = db().execute('SELECT * FROM users WHERE id=?', (session.get('user_id'),)).fetchone() if session.get('user_id') else None
        if 'csrf_token' not in session:
            session['csrf_token'] = secrets.token_hex(32)
        if request.method == 'POST':
            token = request.form.get('csrf_token', '')
            if not token or not secrets.compare_digest(token, session['csrf_token']):
                abort(400, description='Your form expired. Refresh the page and try again.')

    @app.context_processor
    def common():
        return dict(user=g.user, csrf_token=session.get('csrf_token'), categories=CATEGORIES,
                    statuses=STATUSES, priorities=PRIORITIES, today=date.today().isoformat(),
                    demo_mode=app.config['DEMO_MODE'])

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; frame-ancestors 'self'; form-action 'self'; base-uri 'self'"
        if g.get('user'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.route('/')
    def index():
        return redirect(url_for('dashboard' if g.user else 'login'))

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if g.user:
            return redirect(url_for('dashboard'))
        if request.method == 'POST':
            # Small persistent throttle: five failures per username within 15 minutes.
            username = request.form.get('username', '').strip().lower()[:80]
            attempts = db().execute("SELECT count(*) FROM login_attempts WHERE username=? AND created>datetime('now','-15 minutes')", (username,)).fetchone()[0]
            if attempts >= 5:
                flash('Too many attempts for this username. Please try again in 15 minutes.', 'error')
                return render_template('auth.html', mode='login'), 429
            u = db().execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
            if u and check_password_hash(u['password'], request.form.get('password', '')):
                db().execute('DELETE FROM login_attempts WHERE username=?', (username,))
                db().execute("DELETE FROM login_attempts WHERE created<datetime('now','-1 day')")
                db().commit()
                session.clear()
                session['user_id'] = u['id']
                session['csrf_token'] = secrets.token_hex(32)
                flash('Welcome back, ' + u['name'].split()[0] + '.', 'success')
                return redirect(url_for('dashboard'))
            db().execute('INSERT INTO login_attempts(username) VALUES(?)', (username,))
            db().commit()
            flash('The username or password is incorrect.', 'error')
        return render_template('auth.html', mode='login')

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if g.user:
            return redirect(url_for('dashboard'))
        if request.method == 'POST':
            name = request.form.get('name', '').strip()
            username = request.form.get('username', '').strip().lower()
            password = request.form.get('password', '')
            if not 2 <= len(name) <= 60 or not 3 <= len(username) <= 30 or not all(c.isascii() and (c.isalnum() or c in '._') for c in username):
                flash('Use a name of 2–60 characters and a username of 3–30 letters, numbers, dots or underscores.', 'error')
            elif not 8 <= len(password) <= 128:
                flash('Choose a password of 8–128 characters.', 'error')
            elif password != request.form.get('confirm_password'):
                flash('The passwords do not match.', 'error')
            else:
                try:
                    db().execute("INSERT INTO users(name,username,password,role,room) VALUES(?,?,?,'student',?)", (name, username, generate_password_hash(password), request.form.get('room', '').strip()[:50]))
                    db().commit()
                except sqlite3.IntegrityError:
                    flash('That username is already taken.', 'error')
                else:
                    flash('Your account is ready. Sign in to get started.', 'success')
                    return redirect(url_for('login'))
        return render_template('auth.html', mode='register')

    @app.post('/logout')
    def logout():
        session.clear()
        return redirect(url_for('login'))

    def filtered():
        clauses, values = [], []
        if g.user['role'] != 'admin':
            clauses.append('c.user_id=?'); values.append(g.user['id'])
        for key in ['status', 'category', 'priority']:
            value = request.args.get(key, '').strip()
            if value:
                clauses.append('c.' + key + '=?'); values.append(value)
        q = request.args.get('q', '').strip()[:100]
        if q:
            clauses.append("(c.title LIKE ? ESCAPE '\\' OR c.description LIKE ? ESCAPE '\\' OR c.location LIKE ? ESCAPE '\\' OR CAST(c.id AS TEXT)=?)")
            like = '%' + q.replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_') + '%'
            values.extend([like, like, like, q.lstrip('#')])
        if request.args.get('overdue') == '1':
            clauses.append("c.due_date<>'' AND c.due_date<date('now') AND c.status<>'Resolved'")
        where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
        ordering = {'newest': 'c.id DESC', 'oldest': 'c.id ASC', 'priority': "CASE c.priority WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END, c.id DESC"}.get(request.args.get('sort'), 'c.id DESC')
        return where, values, ordering

    @app.get('/dashboard')
    @allowed
    def dashboard():
        where, values, ordering = filtered()
        count = db().execute('SELECT count(*) FROM complaints c' + where, values).fetchone()[0]
        pages = max(1, (count + 7) // 8)
        try:
            page = max(1, min(pages, int(request.args.get('page', 1))))
        except ValueError:
            page = 1
        items = db().execute('SELECT c.*, u.name AS owner_name FROM complaints c JOIN users u ON c.user_id=u.id' + where + ' ORDER BY ' + ordering + ' LIMIT 8 OFFSET ?', values + [(page - 1) * 8]).fetchall()
        own = '' if g.user['role'] == 'admin' else ' WHERE user_id=?'
        args = [] if g.user['role'] == 'admin' else [g.user['id']]
        all_rows = db().execute('SELECT status,priority,due_date FROM complaints' + own, args).fetchall()
        stats = {s: sum(r['status'] == s for r in all_rows) for s in STATUSES}
        stats['Total'] = len(all_rows)
        stats['overdue'] = sum(bool(r['due_date']) and r['due_date'] < date.today().isoformat() and r['status'] != 'Resolved' for r in all_rows)
        stats['rate'] = round(stats['Resolved'] / max(1, stats['Total']) * 100)
        recent = db().execute('SELECT e.*,u.name,c.title FROM events e JOIN users u ON u.id=e.user_id JOIN complaints c ON c.id=e.complaint_id' + ('' if g.user['role'] == 'admin' else ' WHERE c.user_id=?') + ' ORDER BY e.id DESC LIMIT 5', args).fetchall()
        filters = {k: request.args.get(k, '') for k in ['q','status','category','priority','sort','overdue']}
        def page_url(n):
            return url_for('dashboard', **{**filters, 'page': n})
        return render_template('dashboard.html', items=items, stats=stats, recent=recent, count=count, pages=pages, page=page, page_url=page_url, filters=filters)

    def form_values():
        return {k: request.form.get(k, '').strip() for k in ['title','description','category','priority','location']}

    def validate_form(f):
        if not 4 <= len(f['title']) <= 100:
            return 'Give your issue a title of 4–100 characters.'
        if not 15 <= len(f['description']) <= 2000:
            return 'Describe the issue in 15–2,000 characters.'
        if f['category'] not in CATEGORIES or f['priority'] not in PRIORITIES:
            return 'Select a valid category and priority.'
        if not 2 <= len(f['location']) <= 80:
            return 'Add a location of 2–80 characters so we can find the issue.'

    @app.route('/complaints/new', methods=['GET', 'POST'])
    @allowed
    def new_complaint():
        if g.user['role'] != 'student':
            abort(403)
        f = dict(title='', description='', category='Electrical', priority='Medium', location=g.user['room'])
        if request.method == 'POST':
            f = form_values()
            error = validate_form(f)
            if error:
                flash(error, 'error')
            else:
                cursor = db().execute('INSERT INTO complaints(user_id,title,description,category,priority,location) VALUES(?,?,?,?,?,?)', (g.user['id'], f['title'], f['description'], f['category'], f['priority'], f['location']))
                event(cursor.lastrowid, 'created', 'Reported this issue.')
                db().commit()
                flash('Issue reported. Your campus team will take it from here.', 'success')
                return redirect(url_for('detail', cid=cursor.lastrowid))
        return render_template('form.html', form=f, editing=False)

    @app.get('/complaints/<int:cid>')
    @allowed
    def detail(cid):
        row = ticket(cid)
        events = db().execute('SELECT e.*,u.name,u.role FROM events e JOIN users u ON u.id=e.user_id WHERE complaint_id=? ORDER BY e.id ASC', (cid,)).fetchall()
        return render_template('detail.html', item=row, events=events)

    @app.route('/complaints/<int:cid>/edit', methods=['GET', 'POST'])
    @allowed
    def edit(cid):
        row = ticket(cid)
        if g.user['id'] != row['user_id'] or row['status'] != 'Submitted':
            abort(403)
        f = dict(row)
        if request.method == 'POST':
            f = form_values()
            error = validate_form(f)
            if error:
                flash(error, 'error')
            else:
                db().execute("UPDATE complaints SET title=?,description=?,category=?,priority=?,location=?,updated=CURRENT_TIMESTAMP WHERE id=?", tuple(f[k] for k in ['title','description','category','priority','location']) + (cid,))
                event(cid, 'edited', 'Updated the issue details.')
                db().commit()
                flash('Your changes have been saved.', 'success')
                return redirect(url_for('detail', cid=cid))
        return render_template('form.html', form=f, editing=True, cid=cid)

    @app.post('/complaints/<int:cid>/manage')
    @allowed
    def manage(cid):
        admin()
        row = ticket(cid)
        action = request.form.get('action', '')
        if action == 'advance':
            if row['status'] == 'Resolved':
                flash('This issue is already resolved.', 'info')
            else:
                nxt = STATUSES[STATUSES.index(row['status']) + 1]
                db().execute('UPDATE complaints SET status=?,updated=CURRENT_TIMESTAMP WHERE id=?', (nxt, cid))
                event(cid, 'status', row['status'] + ' → ' + nxt)
                flash('Status updated to ' + nxt + '.', 'success')
        elif action == 'assign':
            assigned = request.form.get('assigned_to', '').strip()
            due = request.form.get('due_date', '').strip()
            if len(assigned) > 60:
                abort(400, description='Assignee must be 60 characters or fewer.')
            if due:
                try:
                    date.fromisoformat(due)
                    if len(due) != 10:
                        raise ValueError
                except ValueError:
                    abort(400, description='Use a valid YYYY-MM-DD due date.')
            db().execute('UPDATE complaints SET assigned_to=?,due_date=?,updated=CURRENT_TIMESTAMP WHERE id=?', (assigned, due, cid))
            event(cid, 'assignment', 'Assigned to ' + (assigned or 'Unassigned') + (' · due ' + due if due else ' · no due date'))
            flash('Assignment saved.', 'success')
        else:
            abort(400)
        db().commit()
        return redirect(url_for('detail', cid=cid))

    @app.post('/complaints/<int:cid>/comment')
    @allowed
    def comment(cid):
        ticket(cid)
        body = request.form.get('body', '').strip()
        if not 1 <= len(body) <= 1000:
            flash('Write a comment of 1–1,000 characters.', 'error')
        else:
            event(cid, 'comment', body)
            db().execute('UPDATE complaints SET updated=CURRENT_TIMESTAMP WHERE id=?', (cid,))
            db().commit()
            flash('Comment added.', 'success')
        return redirect(url_for('detail', cid=cid))

    @app.post('/complaints/<int:cid>/reopen')
    @allowed
    def reopen(cid):
        row = ticket(cid)
        reason = request.form.get('reason', '').strip()
        if row['status'] != 'Resolved':
            flash('Only resolved issues can be reopened.', 'error')
        elif not 10 <= len(reason) <= 500:
            flash('Tell us why the issue needs more work (10–500 characters).', 'error')
        else:
            db().execute("UPDATE complaints SET status='In Progress',updated=CURRENT_TIMESTAMP WHERE id=?", (cid,))
            event(cid, 'reopened', reason)
            db().commit()
            flash('Issue reopened. The team can take another look.', 'success')
        return redirect(url_for('detail', cid=cid))

    @app.post('/complaints/<int:cid>/delete')
    @allowed
    def delete(cid):
        admin()
        ticket(cid)
        db().execute('DELETE FROM complaints WHERE id=?', (cid,))
        db().commit()
        flash('Issue permanently deleted.', 'success')
        return redirect(url_for('dashboard'))

    @app.get('/export.csv')
    @allowed
    def export():
        where, values, ordering = filtered()
        rows = db().execute('SELECT c.id,c.title,c.category,c.priority,c.status,c.location,u.name,c.assigned_to,c.due_date,c.created FROM complaints c JOIN users u ON c.user_id=u.id' + where + ' ORDER BY ' + ordering, values).fetchall()
        output = io.StringIO(newline='')
        writer = csv.writer(output)
        writer.writerow(['ID','Title','Category','Priority','Status','Location','Reported by','Assigned to','Due date','Created (UTC)'])
        for row in rows:
            # Neutralize spreadsheet formula injection for user-controlled strings.
            writer.writerow(["'" + str(v) if isinstance(v, str) and v.lstrip().startswith(('=', '+', '-', '@')) else v for v in row])
        response = make_response('\ufeff' + output.getvalue())
        response.headers['Content-Type'] = 'text/csv; charset=utf-8'
        response.headers['Content-Disposition'] = 'attachment; filename=fixit-issues.csv'
        return response

    @app.route('/profile', methods=['GET', 'POST'])
    @allowed
    def profile():
        if request.method == 'POST':
            if request.form.get('action') == 'password':
                old, new = request.form.get('old_password', ''), request.form.get('new_password', '')
                if not check_password_hash(g.user['password'], old):
                    flash('Your current password is incorrect.', 'error')
                elif not 8 <= len(new) <= 128 or new != request.form.get('confirm_password'):
                    flash('Use 8–128 characters and make sure the new passwords match.', 'error')
                else:
                    db().execute('UPDATE users SET password=? WHERE id=?', (generate_password_hash(new), g.user['id']))
                    db().commit()
                    flash('Password updated.', 'success')
            else:
                name, room = request.form.get('name', '').strip(), request.form.get('room', '').strip()
                if not 2 <= len(name) <= 60 or len(room) > 50:
                    flash('Use a name of 2–60 characters and a room of at most 50 characters.', 'error')
                else:
                    db().execute('UPDATE users SET name=?,room=? WHERE id=?', (name, room, g.user['id']))
                    db().commit()
                    flash('Profile updated.', 'success')
            return redirect(url_for('profile'))
        return render_template('profile.html')

    @app.errorhandler(400)
    @app.errorhandler(403)
    @app.errorhandler(404)
    @app.errorhandler(413)
    @app.errorhandler(500)
    def error_page(error):
        return render_template('error.html', code=error.code, message=error.description if error.code in (400,413) else {403:'This space is not available to your account.',404:'We could not find that page or issue.',500:'Something went wrong. Please try again.'}.get(error.code)), error.code

    def init_db():
        db().executescript((ROOT / 'schema.sql').read_text())
        if app.config['DEMO_MODE'] and not db().execute('SELECT 1 FROM users').fetchone():
            for name, username, password, role, room in [('Priya Sharma','admin','admin123','admin','Campus office'),('Aarav Mehta','aarav','student123','student','Maple Hall · Room 214'),('Meera Nair','meera','student123','student','Cedar Hall · Room 308')]:
                db().execute('INSERT INTO users(name,username,password,role,room) VALUES(?,?,?,?,?)', (name, username, generate_password_hash(password), role, room))
            samples = [
                (2,'Ceiling fan needs a little help','The ceiling fan rattles loudly and stops after a few minutes. Could someone check the motor?','Electrical','High','Maple Hall · Room 214','In Progress','Ravi · Electrical',2),
                (3,'Wi-Fi drops during evening classes','The third-floor Wi-Fi disconnects repeatedly after 8 PM. It affects our online study sessions.','Internet / Wi-Fi','High','Cedar Hall · Third floor','Submitted','',0),
                (2,'Water tap is leaking overnight','The washbasin tap keeps dripping even when fully closed. Please replace the worn washer.','Plumbing','Medium','Maple Hall · Second floor','Submitted','',0),
                (3,'Study lounge could use a clean-up','The study tables and windows need cleaning before the weekend study group meets.','Cleanliness','Low','Library · Study lounge','Resolved','Housekeeping',-1),
                (2,'A better vegetarian lunch option','Could we add a protein-rich vegetarian option to the lunch menu? The current choices are limited.','Mess / Food','Low','Main dining hall','Resolved','Dining team',-2),
                (3,'Corridor light is flickering','The light near the staircase flickers constantly, making it difficult to walk safely at night.','Electrical','Medium','Cedar Hall · Staircase B','In Progress','Ravi · Electrical',-1),
                (2,'Laundry room notice board is loose','The wooden notice board is coming away from the wall. Please secure it before it falls.','Other','Medium','Maple Hall · Laundry room','Submitted','',0),
                (3,'Water cooler is not cooling','The dispenser runs but the water stays warm even after an hour. The filter may need checking.','Plumbing','High','Sports block · Ground floor','Submitted','',0),
                (2,'Garden pathway needs sweeping','Dry leaves have collected on the pathway after the rain. They are slippery in the morning.','Cleanliness','Low','Garden · East path','Resolved','Grounds team',-3),
            ]
            for n, s in enumerate(samples):
                uid, title, desc, cat, priority, loc, status, assigned, offset = s
                created = (date.today() - timedelta(days=8-n)).isoformat() + ' 09:30:00'
                due = (date.today()+timedelta(days=offset)).isoformat() if assigned else ''
                cur = db().execute('INSERT INTO complaints(user_id,title,description,category,priority,location,status,assigned_to,due_date,created,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)', (uid,title,desc,cat,priority,loc,status,assigned,due,created,created))
                db().execute("INSERT INTO events(complaint_id,user_id,kind,body,created) VALUES(?,?,'created','Reported this issue.',?)", (cur.lastrowid,uid,created))
                if status != 'Submitted':
                    db().execute("INSERT INTO events(complaint_id,user_id,kind,body,created) VALUES(?,1,'status',?,?)", (cur.lastrowid,'Submitted → In Progress',created))
                if assigned:
                    db().execute("INSERT INTO events(complaint_id,user_id,kind,body,created) VALUES(?,1,'assignment',?,?)", (cur.lastrowid,'Assigned to '+assigned,created))
                if status == 'Resolved':
                    db().execute("INSERT INTO events(complaint_id,user_id,kind,body,created) VALUES(?,1,'status','In Progress → Resolved',?)", (cur.lastrowid,created))
            db().commit()

    @app.cli.command('create-admin')
    def create_admin():
        """Create an administrator interactively (works with DEMO_MODE=0)."""
        import click
        username = click.prompt('Username').strip().lower()
        name = click.prompt('Display name').strip()
        password = click.prompt('Password (8–128 characters)', hide_input=True, confirmation_prompt=True)
        if not 3 <= len(username) <= 30 or not all(c.isascii() and (c.isalnum() or c in '._') for c in username) or not 2 <= len(name) <= 60 or not 8 <= len(password) <= 128:
            raise click.ClickException('Invalid username, display name or password length.')
        try:
            db().execute("INSERT INTO users(name,username,password,role) VALUES(?,?,?,'admin')", (name,username,generate_password_hash(password)))
            db().commit()
        except sqlite3.IntegrityError:
            raise click.ClickException('Username already exists.')
        click.echo('Administrator created.')

    with app.app_context():
        init_db()
    return app


if __name__ == '__main__':
    create_app().run(host=os.environ.get('HOST','127.0.0.1'), port=int(os.environ.get('PORT','5000')), debug=False)
