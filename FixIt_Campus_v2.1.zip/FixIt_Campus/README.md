# fixit. — Campus care, simplified

A polished, intentionally small **Flask + SQLite mini project** for reporting and resolving hostel/campus issues. No Node.js, database server, CDN, paid API, or external frontend framework is required.

**A little care. A better campus.**

![Student overview](docs/screenshots/02_student_dashboard.png)

## Start here

**Prerequisite:** Python **3.10 or newer**, including pip and venv. The project was verified on Python 3.13. Internet is needed once to install the Python dependencies; the application then runs locally without external assets.

### Windows

1. Extract the ZIP completely.
2. Open the `FixIt_Campus` folder.
3. Double-click **`start.bat`**.
4. Keep the terminal open and visit **http://127.0.0.1:5000**.

### macOS / Linux

```sh
cd FixIt_Campus
sh start.sh
```

Visit **http://127.0.0.1:5000**. Keep the terminal open. Stop the server with **Ctrl+C**.

### Manual setup (all platforms)

```sh
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
# source .venv/bin/activate
python -m pip install -r requirements.txt
python run.py
```

On systems where `python` is not available, use `python3` or Windows `py`.

## Demo accounts

| Role | Username | Password |
|---|---|---|
| Administrator | `admin` | `admin123` |
| Student | `aarav` | `student123` |
| Student | `meera` | `student123` |

The welcome screen includes account-fill buttons. They fill the form; click **Sign in** to continue. Nine realistic sample issues are seeded automatically on the first start. New users can register a **student** account; administrators cannot be self-registered.

## What is included?

### A considered interface
- Soft emerald and cream palette, handcrafted local SVG icons, generous whitespace and a custom CSS campus illustration.
- Responsive sidebar, mobile navigation, clean cards, status badges and a visual progress ring.
- Persistent **light/dark mode**, empty states, toasts and a confirmation dialog for deletion.
- Native forms, visible labels, keyboard focus styles, skip link, reduced-motion support and printable layouts.
- No external fonts or image downloads. The app stays visually complete offline after dependency installation.

### Student workspace
- Register, sign in and update your profile or password.
- Report a categorized issue with priority, location and descriptive details.
- See only your own issues, dashboard counts and recent activity.
- Edit your own issue **while it is Submitted**.
- Follow a dedicated details page with a persistent activity timeline.
- Comment with the campus team and reopen resolved issues with a reason.
- Search, filter, sort, paginate and export your own matching issues as CSV.

### Administrator workspace
- Review the campus-wide issue queue and overview counts.
- Advance issues through **Submitted → In Progress → Resolved**.
- Record a team/person label and a planned due date.
- Find overdue unresolved work with a one-click filter.
- Comment, reopen issues, and export the filtered campus report.
- Permanently delete an issue and its activity through a confirmation flow.

### Practical safeguards
- Werkzeug password hashing; per-request DB connections explicitly closed.
- CSRF tokens for every POST; logout is POST-only.
- Ownership checks and server-side role authorization.
- Parameterized SQL, server validation, foreign keys and database CHECK constraints.
- Locally generated persistent session secret (or `SECRET_KEY` environment override).
- Basic username-based login throttling: 5 failed attempts within 15 minutes.
- Security headers, HTML autoescaping, CSV formula neutralization and a request size limit.
- Demo mode can be disabled; administrator creation is available through a CLI command.

## Project layout

```text
FixIt_Campus/
├── app.py                    # Application factory, routes, validation, permissions
├── schema.sql                # Users, complaints, events, login attempts, indexes
├── run.py                    # Local Waitress launcher (Flask fallback)
├── requirements.txt          # Two pinned runtime dependencies
├── start.bat / start.sh      # Easy launchers
├── templates/                # Jinja pages and reusable SVG/form macros
├── static/                   # Self-contained CSS, JavaScript and favicon
├── tests/test_app.py         # 50 isolated integration tests
├── docs/
│   ├── SRS.pdf / SRS.docx
│   ├── Project_Report.pdf / Project_Report.docx
│   ├── UML_Diagrams.pdf / UML_Diagrams.docx
│   ├── User_Guide.pdf
│   ├── diagrams/             # SVG, PNG and editable PlantUML source
│   ├── screenshots/          # Actual application screenshots
│   ├── test-results.txt      # Captured unittest output
│   └── browser-checks.txt    # Captured browser workflow checks
└── instance/                 # Created at runtime; intentionally NOT in the ZIP
```

## Tests

```sh
python -m unittest discover -s tests -v
```

All **50 tests passed** in the verification run. Tests use a temporary database and do not modify your running demo data. Browser checks additionally exercised student creation/commenting, admin resolution, theme persistence, a 390 px mobile layout, navigation/profile, and cancel/confirm deletion in Chromium. See the raw results in `docs/`.

Test count is not a claim of exhaustive security, cross-browser or load testing. The included screenshots show actual browser-rendered pages, not mockups.

## A five-minute demonstration

1. Sign in as **aarav**. Notice that Meera's issues are not in your queue.
2. Report a new issue with a location and at least 15 description characters.
3. Open it and add a comment. While Submitted, try **Edit**.
4. Sign out, then sign in as **admin**. Open the new report.
5. Assign a team label and due date. Click **Start working on it**.
6. Add a response, then **Mark as resolved**. The activity history remains visible.
7. Sign in as the student and reopen it with a reason if it needs another look.
8. Try search, category/priority filters, CSV export and the theme switch.

## Data and reset

- Runtime data: `instance/fixit.db`. Timestamps are stored/displayed in **UTC**; planned due dates are date-only values.
- Stop the server before copying the database for a local backup.
- To reset the demo, stop the server and delete **only** `instance/fixit.db`, then restart. **This destroys all saved users, issues and history.**
- Do not delete `.session-secret` unless you intentionally want all current sessions invalidated.
- This is a redesigned version, **not an in-place migration** for the original uploaded database. Use a fresh extracted folder; do not copy the old `fixit.db` into this app.

## Configuration and non-demo use

Environment variables:

| Name | Default | Meaning |
|---|---|---|
| `DEMO_MODE` | `1` | Seed demo accounts/issues on an empty users table; show demo helpers |
| `SECRET_KEY` | locally generated file | Override Flask signing secret |
| `HOST` | `127.0.0.1` | Local-only bind; set `0.0.0.0` only for an intentionally shared host |
| `PORT` | `5000` | HTTP port |
| `COOKIE_SECURE` | `0` | Set `1` only behind HTTPS; cookies will not work over plain local HTTP |

For a clean, non-demo start, use a **fresh extracted directory**, set `DEMO_MODE=0` **before** the first launch, then run:

```sh
python -m flask --app app:create_app create-admin
python run.py
```

Set environment variables for your shell first:
- macOS/Linux: `export DEMO_MODE=0`
- Windows PowerShell: `$env:DEMO_MODE="0"`
- Windows cmd: `set DEMO_MODE=0`

**Turning off demo mode does not delete existing demo accounts.** Use a new directory/database or deliberately remove them through a separately reviewed administrative process. Keep environment variables consistent for CLI and server processes.

`assigned_to` is a **plain team/person label**, not a technician role, account or dispatch service. Counts reflect the signed-in user's full authorized scope, not just the current filters. The status ring is a resolution percentage, not a real-time feed. The campus-connected label is decorative; there is no online-presence service.

## Known boundaries

This remains a mini project: no email/SMS/push notifications, file attachments, password recovery, account administration screen, third-party sign-in or live websocket updates. There is no SLA guarantee or technician login. Timeline events are retained unless an admin permanently deletes the whole issue; this is not a tamper-proof regulatory audit log.

The basic username throttle can be abused to temporarily block a known account and is not a substitute for production abuse controls. Registration has no CAPTCHA or email verification. SQLite is suited to light local/demo use; distributed multi-instance hosting and high-concurrency workflows have not been qualified. Password changes do not revoke other active sessions. No formal accessibility certification, security audit or load benchmark is claimed.

For public deployment: use HTTPS/reverse proxy configuration, stronger rate limits, account governance, session revocation, backup/restore procedures, monitoring, and an appropriately reviewed database/deployment design. Never expose demo credentials publicly. This is not an emergency reporting service.

## Troubleshooting

- **Port in use:** change `PORT` (e.g. `5001`) in your terminal, then restart.
- **`No module named flask`:** activate the virtual environment and install `requirements.txt`.
- **`venv` unavailable on Linux:** install your distribution's Python venv package.
- **Form expired:** refresh the page and submit again. Multiple tabs opened before signing in may retain old CSRF tokens.
- **Too many login attempts:** wait 15 minutes and use the correct password.
- **No issues shown:** clear the search/filters. A newly registered student starts with an empty dashboard.
- **Permission/database errors:** extract into a normal writable local folder, not a read-only directory. Do not run from inside the ZIP.
- **Missing Python on Windows:** install Python with **Add Python to PATH** enabled, then reopen the terminal.

## Documentation

The SRS, UML package and project report have been rewritten to match this version, including its changed validation rules, new event model, reopening workflow and security controls. Editable Word and PlantUML versions are included for customization. Institution, author and supervisor details were not supplied and have not been invented.
