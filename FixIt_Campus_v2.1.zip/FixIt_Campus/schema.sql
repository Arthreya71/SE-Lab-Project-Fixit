PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY,
 name TEXT NOT NULL,
 username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','student')),
 room TEXT NOT NULL DEFAULT '',
 created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS complaints (
 id INTEGER PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id),
 title TEXT NOT NULL CHECK(length(title) BETWEEN 4 AND 100),
 description TEXT NOT NULL CHECK(length(description) BETWEEN 15 AND 2000),
 category TEXT NOT NULL CHECK(category IN ('Electrical','Plumbing','Internet / Wi-Fi','Cleanliness','Mess / Food','Other')),
 priority TEXT NOT NULL CHECK(priority IN ('Low','Medium','High')),
 location TEXT NOT NULL CHECK(length(location) BETWEEN 2 AND 80),
 status TEXT NOT NULL DEFAULT 'Submitted' CHECK(status IN ('Submitted','In Progress','Resolved')),
 assigned_to TEXT NOT NULL DEFAULT '',
 due_date TEXT NOT NULL DEFAULT '',
 created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS events (
 id INTEGER PRIMARY KEY,
 complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id),
 kind TEXT NOT NULL CHECK(kind IN ('created','edited','status','assignment','comment','reopened')),
 body TEXT NOT NULL,
 created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS login_attempts (
 id INTEGER PRIMARY KEY,
 username TEXT NOT NULL,
 created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_complaints_owner_status ON complaints(user_id,status);
CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);
CREATE INDEX IF NOT EXISTS idx_events_complaint ON events(complaint_id,id);
CREATE INDEX IF NOT EXISTS idx_login_attempts ON login_attempts(username,created);
CREATE TABLE IF NOT EXISTS feedback (
 complaint_id INTEGER PRIMARY KEY REFERENCES complaints(id) ON DELETE CASCADE,
 rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
 comment TEXT NOT NULL DEFAULT '' CHECK(length(comment) <= 300),
 created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS announcements (
 id INTEGER PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id),
 title TEXT NOT NULL CHECK(length(title) BETWEEN 3 AND 80),
 body TEXT NOT NULL CHECK(length(body) BETWEEN 5 AND 300),
 created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
