"""Isolated integration tests. Run: python -m unittest discover -s tests -v"""
from contextlib import closing
import csv
import io
import os
import sqlite3
import tempfile
import unittest
from app import create_app


class CampusTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.directory = tempfile.TemporaryDirectory()
        cls.path = os.path.join(cls.directory.name, 'base.db')
        cls.app = create_app({'TESTING': True, 'SECRET_KEY': 'test-only', 'DATABASE': cls.path, 'DEMO_MODE': True})
        with open(cls.path, 'rb') as f:
            cls.base = f.read()

    @classmethod
    def tearDownClass(cls):
        cls.directory.cleanup()

    def setUp(self):
        with open(self.path, 'wb') as f:
            f.write(self.base)
        self.client = self.app.test_client()

    def query(self, sql, args=()):
        with closing(sqlite3.connect(self.path)) as c:
            c.row_factory = sqlite3.Row
            return c.execute(sql, args).fetchall()

    def post(self, path, data=None, follow=True):
        with self.client.session_transaction() as s:
            if 'csrf_token' not in s:
                s['csrf_token'] = 'testing-token'
            token = s['csrf_token']
        return self.client.post(path, data={**(data or {}), 'csrf_token': token}, follow_redirects=follow)

    def login(self, username='aarav', password='student123'):
        return self.post('/login', {'username': username, 'password': password})

    def form(self, **kwargs):
        return dict(title='Broken study chair', description='The back support is loose and needs to be repaired.', category='Other', priority='Medium', location='Library · Room 12', **kwargs)

    def test_01_login_page_and_static(self):
        self.assertIn(b'Good to see you again', self.client.get('/login').data)
        r = self.client.get('/static/style.css')
        self.assertEqual(r.status_code, 200)
        r.close()

    def test_02_successful_student_login(self):
        self.assertIn(b'Your reported issues', self.login().data)

    def test_03_admin_login(self):
        self.assertIn(b'Campus issues', self.login('admin','admin123').data)

    def test_04_bad_login(self):
        self.assertIn(b'username or password is incorrect', self.login(password='wrong').data)

    def test_05_login_throttle(self):
        for _ in range(5):
            self.login(password='wrong')
        self.assertEqual(self.login(password='wrong').status_code,429)

    def test_06_csrf_required(self):
        self.assertEqual(self.client.post('/login',data={'username':'aarav','password':'student123'}).status_code,400)

    def test_07_anonymous_dashboard_redirect(self):
        self.assertEqual(self.client.get('/dashboard').status_code,302)

    def test_08_ownership_scope(self):
        self.login()
        html = self.client.get('/dashboard').data
        self.assertIn(b'Ceiling fan needs a little help',html)
        self.assertNotIn(b'Wi-Fi drops during evening classes',html)

    def test_09_detail_forbidden(self):
        self.login()
        self.assertEqual(self.client.get('/complaints/2').status_code,403)

    def test_10_create_valid(self):
        self.login()
        r=self.post('/complaints/new',self.form())
        self.assertEqual(r.status_code,200)
        row=self.query('SELECT * FROM complaints ORDER BY id DESC')[0]
        self.assertEqual(row['title'],'Broken study chair')
        self.assertEqual(row['status'],'Submitted')
        self.assertEqual(len(self.query('SELECT * FROM events WHERE complaint_id=?',(row['id'],))),1)

    def test_11_invalid_title_no_insert(self):
        self.login()
        f=self.form(); f['title']=' '
        self.assertIn(b'title of 4',self.post('/complaints/new',f).data)
        self.assertEqual(len(self.query('SELECT * FROM complaints')),9)

    def test_12_invalid_description(self):
        self.login()
        f=self.form(); f['description']='Too short'
        self.assertIn(b'Describe the issue',self.post('/complaints/new',f).data)
        self.assertEqual(len(self.query('SELECT * FROM complaints')),9)

    def test_13_invalid_category(self):
        self.login()
        f=self.form(); f['category']='Injected'
        self.assertIn(b'valid category',self.post('/complaints/new',f).data)
        self.assertEqual(len(self.query('SELECT * FROM complaints')),9)

    def test_14_invalid_priority(self):
        self.login()
        f=self.form(); f['priority']='Critical'
        self.assertIn(b'valid category and priority',self.post('/complaints/new',f).data)

    def test_15_invalid_location(self):
        self.login()
        f=self.form(); f['location']=''
        self.assertIn(b'Add a location',self.post('/complaints/new',f).data)

    def test_16_missing_fields_friendly(self):
        self.login()
        self.assertEqual(self.post('/complaints/new',{}).status_code,200)
        self.assertEqual(len(self.query('SELECT * FROM complaints')),9)

    def test_17_admin_cannot_submit(self):
        self.login('admin','admin123')
        self.assertEqual(self.post('/complaints/new',self.form()).status_code,403)

    def test_18_student_cannot_advance(self):
        self.login()
        self.assertEqual(self.post('/complaints/1/manage',{'action':'advance'}).status_code,403)
        self.assertEqual(self.query('SELECT status FROM complaints WHERE id=1')[0][0],'In Progress')

    def test_19_admin_advances_and_logs(self):
        self.login('admin','admin123')
        self.post('/complaints/2/manage',{'action':'advance'})
        self.assertEqual(self.query('SELECT status FROM complaints WHERE id=2')[0][0],'In Progress')
        self.assertEqual(self.query('SELECT body FROM events WHERE complaint_id=2 ORDER BY id DESC')[0][0],'Submitted → In Progress')

    def test_20_resolved_terminal_advance(self):
        self.login('admin','admin123')
        self.post('/complaints/4/manage',{'action':'advance'})
        self.assertEqual(self.query('SELECT status FROM complaints WHERE id=4')[0][0],'Resolved')

    def test_21_assign_and_due_date(self):
        self.login('admin','admin123')
        self.post('/complaints/2/manage',{'action':'assign','assigned_to':'Network team','due_date':'2026-12-30'})
        row=self.query('SELECT assigned_to,due_date FROM complaints WHERE id=2')[0]
        self.assertEqual(tuple(row),('Network team','2026-12-30'))

    def test_22_invalid_due_date(self):
        self.login('admin','admin123')
        self.assertEqual(self.post('/complaints/2/manage',{'action':'assign','due_date':'not-a-date'}).status_code,400)

    def test_23_owner_can_edit_submitted(self):
        self.login()
        self.assertEqual(self.post('/complaints/3/edit',self.form()).status_code,200)
        self.assertEqual(self.query('SELECT title FROM complaints WHERE id=3')[0][0],'Broken study chair')

    def test_24_cannot_edit_active(self):
        self.login()
        self.assertEqual(self.post('/complaints/1/edit',self.form()).status_code,403)

    def test_25_comment_and_xss_escaping(self):
        self.login()
        r=self.post('/complaints/1/comment',{'body':'<script>alert(1)</script>'})
        self.assertIn(b'&lt;script&gt;alert(1)&lt;/script&gt;',r.data)
        self.assertNotIn(b'<script>alert(1)</script>',r.data)

    def test_26_other_student_cannot_comment(self):
        self.login()
        self.assertEqual(self.post('/complaints/2/comment',{'body':'hello'}).status_code,403)

    def test_27_reopen_resolved(self):
        self.login()
        self.post('/complaints/5/reopen',{'reason':'The menu has not changed yet.'})
        self.assertEqual(self.query('SELECT status FROM complaints WHERE id=5')[0][0],'In Progress')
        self.assertEqual(self.query('SELECT kind FROM events WHERE complaint_id=5 ORDER BY id DESC')[0][0],'reopened')

    def test_28_reopen_requires_reason(self):
        self.login()
        self.post('/complaints/5/reopen',{'reason':'no'})
        self.assertEqual(self.query('SELECT status FROM complaints WHERE id=5')[0][0],'Resolved')

    def test_29_delete_cascades(self):
        self.login('admin','admin123')
        self.post('/complaints/1/delete')
        self.assertFalse(self.query('SELECT * FROM complaints WHERE id=1'))
        self.assertFalse(self.query('SELECT * FROM events WHERE complaint_id=1'))

    def test_30_student_cannot_delete(self):
        self.login()
        self.assertEqual(self.post('/complaints/1/delete').status_code,403)
        self.assertTrue(self.query('SELECT * FROM complaints WHERE id=1'))

    def test_31_status_filter(self):
        self.login()
        html=self.client.get('/dashboard?status=Resolved').data
        self.assertIn(b'A better vegetarian lunch option',html)
        self.assertNotIn(b'Ceiling fan needs a little help',html)

    def test_32_search(self):
        self.login()
        html=self.client.get('/dashboard?q=leaking').data
        self.assertIn(b'Water tap is leaking overnight',html)
        self.assertNotIn(b'Ceiling fan needs a little help',html)

    def test_33_export_scope(self):
        self.login()
        r=self.client.get('/export.csv')
        rows=list(csv.reader(io.StringIO(r.data.decode('utf-8-sig'))))
        self.assertEqual(len(rows),6)
        self.assertTrue(all(row[6]=='Aarav Mehta' for row in rows[1:]))

    def test_34_export_formula_safety(self):
        self.login()
        f=self.form();f['title']='=1+1 test'
        self.post('/complaints/new',f)
        self.assertIn(b"'=1+1 test",self.client.get('/export.csv').data)

    def test_35_register_student_only(self):
        r=self.post('/register',{'name':'Test Student','username':'new_student','password':'safe12345','confirm_password':'safe12345','role':'admin'})
        row=self.query("SELECT * FROM users WHERE username='new_student'")[0]
        self.assertEqual(row['role'],'student')
        self.assertNotEqual(row['password'],'safe12345')
        self.assertIn(b'account is ready',r.data)

    def test_36_duplicate_username(self):
        self.assertIn(b'already taken',self.post('/register',{'name':'Test User','username':'aarav','password':'safe12345','confirm_password':'safe12345'}).data)

    def test_37_change_password(self):
        self.login()
        self.post('/profile',{'action':'password','old_password':'student123','new_password':'newpass123','confirm_password':'newpass123'})
        self.post('/logout')
        self.assertIn(b'Your reported issues',self.login(password='newpass123').data)

    def test_38_profile_update(self):
        self.login()
        self.post('/profile',{'name':'Aarav Updated','room':'Birch 12','action':'profile'})
        self.assertEqual(self.query('SELECT room FROM users WHERE id=2')[0][0],'Birch 12')

    def test_39_logout_post_only(self):
        self.login()
        self.assertEqual(self.client.get('/logout').status_code,405)
        self.post('/logout')
        self.assertEqual(self.client.get('/dashboard').status_code,302)

    def test_40_missing_ticket(self):
        self.login()
        self.assertEqual(self.client.get('/complaints/9999').status_code,404)

    def test_41_pagination_and_invalid_page(self):
        self.login('admin','admin123')
        self.assertIn(b'1 / 2',self.client.get('/dashboard').data)
        self.assertIn(b'2 / 2',self.client.get('/dashboard?page=2').data)
        self.assertEqual(self.client.get('/dashboard?page=invalid').status_code,200)

    def test_42_security_headers(self):
        self.login()
        r=self.client.get('/dashboard')
        self.assertIn("default-src 'self'",r.headers['Content-Security-Policy'])
        self.assertEqual(r.headers['Cache-Control'],'no-store')

    def test_43_overdue_filter(self):
        self.login('admin','admin123')
        html=self.client.get('/dashboard?overdue=1').data
        self.assertIn(b'Corridor light is flickering',html)
        self.assertNotIn(b'Ceiling fan needs a little help',html)

    def test_44_invalid_registration_password(self):
        self.assertIn(b'8',self.post('/register',{'name':'New Student','username':'newstudent','password':'tiny','confirm_password':'tiny'}).data)
        self.assertFalse(self.query("SELECT * FROM users WHERE username='newstudent'"))

    def test_45_empty_comment_no_event(self):
        self.login()
        before=len(self.query('SELECT * FROM events'))
        self.post('/complaints/1/comment',{'body':' '})
        self.assertEqual(len(self.query('SELECT * FROM events')),before)

    def test_47_rendered_csrf_form_works(self):
        import re
        page=self.client.get('/login')
        token=re.search(rb'name="csrf_token" value="([^"]+)"',page.data).group(1).decode()
        r=self.client.post('/login',data={'username':'aarav','password':'student123','csrf_token':token},follow_redirects=True)
        self.assertIn(b'Your reported issues',r.data)

    def test_48_wrong_old_password_no_change(self):
        self.login()
        self.assertIn(b'current password is incorrect',self.post('/profile',{'action':'password','old_password':'wrong','new_password':'newpass123','confirm_password':'newpass123'}).data)
        self.post('/logout')
        self.assertIn(b'Your reported issues',self.login().data)

    def test_49_category_priority_combined_filter(self):
        self.login('admin','admin123')
        html=self.client.get('/dashboard?category=Electrical&priority=High').data
        self.assertIn(b'Ceiling fan needs a little help',html)
        self.assertNotIn(b'Corridor light is flickering',html)

    def test_50_search_literal_percent(self):
        self.login()
        self.assertIn(b'No matches this time',self.client.get('/dashboard?q=%25').data)

    def test_46_demo_disabled_clean_database(self):
        clean=create_app({'TESTING':True,'SECRET_KEY':'test','DATABASE':os.path.join(self.directory.name,'clean.db'),'DEMO_MODE':False})
        self.assertNotIn(b'TAKE A LOOK AROUND',clean.test_client().get('/login').data)
        with closing(sqlite3.connect(clean.config['DATABASE'])) as c:
            self.assertEqual(c.execute('SELECT count(*) FROM users').fetchone()[0],0)


    def test_51_insights_admin_only(self):
        self.login('admin', 'admin123')
        r = self.client.get('/insights')
        self.assertEqual(r.status_code, 200)
        self.assertIn(b'Campus', r.data)
        self.client.post('/logout', data={'csrf_token': 'x'})
        self.client = self.app.test_client()
        self.login('aarav', 'student123')
        self.assertEqual(self.client.get('/insights').status_code, 403)

    def test_52_feedback_rules(self):
        self.login('aarav', 'student123')
        self.post('/complaints/5/feedback', {'rating': '3', 'comment': 'Fine'})
        self.assertEqual(self.query('SELECT rating FROM feedback WHERE complaint_id=5')[0]['rating'], 3)
        self.post('/complaints/5/feedback', {'rating': '9'})
        self.assertEqual(self.query('SELECT rating FROM feedback WHERE complaint_id=5')[0]['rating'], 3)
        self.post('/complaints/3/feedback', {'rating': '5'})
        self.assertEqual(self.query('SELECT count(*) c FROM feedback WHERE complaint_id=3')[0]['c'], 0)
        self.assertEqual(self.post('/complaints/4/feedback', {'rating': '5'}, follow=False).status_code, 403)

    def test_53_announcements(self):
        self.login('aarav', 'student123')
        self.assertEqual(self.post('/announcements', {'title': 'Hello', 'body': 'Not allowed'}, follow=False).status_code, 403)
        self.client = self.app.test_client()
        self.login('admin', 'admin123')
        self.post('/announcements', {'title': 'x', 'body': 'too short title'})
        self.assertEqual(self.query("SELECT count(*) c FROM announcements WHERE title='x'")[0]['c'], 0)
        r = self.post('/announcements', {'title': 'Library hours', 'body': 'Open until 10 PM during exams.'})
        self.assertIn(b'Library hours', r.data)


if __name__ == '__main__':
    unittest.main()
